import tkinter as tk
import json

# FUCKING SUCCESSSSSSSS
data = []
data2 = []

class toDoList:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title('Leastlist!')
        self.root.geometry('600x250')
        self.root.config(bg='orange')
        self.root.resizable(False,False)

        self.root.after_idle(self.load)

        self.top = tk.Label(self.root, text='Welcome to Leastlist!', font=('Courier', 24, 'bold'), bg='orange')
        self.top.pack(pady=10)

        # listbox area
        self.textarea = tk.Frame(self.root,bg='pink')
        self.textarea.pack(side='right', padx=10, pady=20)

        self.listbox = tk.Listbox(self.textarea, width=25, height=10, font=('Avenir', 12), cursor='hand2')
        self.listbox.pack(side='left', pady=20)
        self.listbox.bind('<KeyPress>', self.del_shortcut)
        self.listbox.bind('<KeyPress>', self.edit_shortcut, add='+')

        self.scrollbar = tk.Scrollbar(self.textarea)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.BOTH)

        self.listbox.config(yscrollcommand=self.scrollbar.set)
        self.scrollbar.config(command=self.listbox.yview)
        #listbox area - end

        #toolbar area
        self.area1 = tk.Frame(self.root, bg='pink')
        self.area1.pack(side='left', padx=20, pady=20)

        self.area1_label = tk.Label(self.area1, text='List Taskbar', font=('Avenir', 12), bg='lightgreen')
        self.area1_label.pack(padx=20, pady=10)

        self.area2 = tk.Frame(self.area1)
        self.area2.pack(side='top', padx=20, pady=20)
        self.area2.grid_columnconfigure((0,1,2), weight=1)

        self.addbtn = tk.Button(self.area2, text='Add Task', font=('Avenir', 12), command=self.addclick)
        self.addbtn.grid(row=0, column=0, sticky=tk.W+tk.E)

        self.delbtn = tk.Button(self.area2, text='Delete Task', font=('Avenir', 12), command=self.deltask)
        self.delbtn.grid(row=0, column=1, sticky=tk.W + tk.E)

        self.editbtn = tk.Button(self.area2, text='Edit Task', font=('Avenir', 12), command=self.edittask)
        self.editbtn.grid(row=0, column=2, sticky=tk.W + tk.E)

        self.inputbox = tk.Entry(self.area2, width=20, font=('Avenir', 14))
        self.inputbox.grid(row=1, columnspan=3)
        self.inputbox.bind('<Return>', self.add_shortcut)
        #toolbar area - end

        self.root.protocol('WM_DELETE_WINDOW', self.on_closing)
        self.root.mainloop()

    def clear(self):
        self.inputbox.delete(0, tk.END)

    def addclick(self):
        if self.inputbox.get() == '':
            print('Invalid task!')
        else:
            global data
            task = self.inputbox.get()
            self.listbox.insert(1, f'{task}')
            data.append(task)
            print('Task Added!')
            self.clear()

    def add_shortcut(self, event):
            self.addclick()

    def edittask(self):
        for i in self.listbox.curselection():
            self.inputbox.insert(1, self.listbox.get(i))
            self.deltask()

    def edit_shortcut(self, event):
        if event.state == 4 and event.keysym == 'e':
            self.edittask()

    def deltask(self):
        for i in self.listbox.curselection():
            self.listbox.delete(self.listbox.curselection())

    def del_shortcut(self, event):
        if event.state == 0 and event.keysym == 'BackSpace':
            self.deltask()

    def on_closing(self):
        global data
        global t
        for task in self.listbox.get(0, tk.END):
            data.append(task)
        for t in data:
            if t not in data2:
                data2.append(t)
        with open('tasklist.json', 'w') as file:
            json.dump(data2, file)
        self.root.destroy()

    def load(self):
        with open('tasklist.json', 'r') as file:
            for task in json.load(file):
                self.listbox.insert(0, task)

toDoList()